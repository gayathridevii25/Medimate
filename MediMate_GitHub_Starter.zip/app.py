import sqlite3
from datetime import date, datetime, time
from pathlib import Path

import streamlit as st

# -------------------- PAGE CONFIG --------------------
st.set_page_config(
    page_title="MediMate | Medicine Reminder",
    page_icon="💊",
    layout="wide",
    initial_sidebar_state="expanded",
)

DB_PATH = Path(__file__).with_name("medimate.db")


# -------------------- DATABASE --------------------
def get_connection():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS medicines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                dosage TEXT NOT NULL,
                start_date TEXT NOT NULL,
                reminder_time TEXT NOT NULL,
                notes TEXT DEFAULT '',
                created_at TEXT NOT NULL
            )
            """
        )


def add_medicine(name, dosage, start_date, reminder_time, notes):
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO medicines
                (name, dosage, start_date, reminder_time, notes, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                name.strip(),
                dosage.strip(),
                start_date.isoformat(),
                reminder_time.strftime("%H:%M"),
                notes.strip(),
                datetime.now().isoformat(timespec="seconds"),
            ),
        )


def get_medicines(search_term=""):
    with get_connection() as conn:
        if search_term.strip():
            pattern = f"%{search_term.strip()}%"
            return conn.execute(
                """
                SELECT * FROM medicines
                WHERE name LIKE ? OR dosage LIKE ? OR notes LIKE ?
                ORDER BY start_date ASC, reminder_time ASC, name COLLATE NOCASE ASC
                """,
                (pattern, pattern, pattern),
            ).fetchall()
        return conn.execute(
            """
            SELECT * FROM medicines
            ORDER BY start_date ASC, reminder_time ASC, name COLLATE NOCASE ASC
            """
        ).fetchall()


def delete_medicine(medicine_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM medicines WHERE id = ?", (medicine_id,))


init_db()


# -------------------- STYLING --------------------
st.markdown(
    """
    <style>
    .stApp {
        background: linear-gradient(180deg, #f6f9ff 0%, #ffffff 42%);
    }
    .block-container {
        padding-top: 1.6rem;
        padding-bottom: 2.5rem;
        max-width: 1200px;
    }
    .hero {
        background: linear-gradient(120deg, #123a72, #2563a6);
        padding: 1.7rem 1.8rem;
        border-radius: 22px;
        color: white;
        margin-bottom: 1.2rem;
        box-shadow: 0 10px 28px rgba(25, 72, 130, 0.14);
    }
    .hero h1 {
        color: white;
        font-size: 2.25rem;
        margin: 0;
        padding: 0;
    }
    .hero p {
        color: #e7f1ff;
        font-size: 1rem;
        margin: .45rem 0 0 0;
    }
    .metric-card {
        background: white;
        border: 1px solid #e4ebf5;
        border-radius: 16px;
        padding: 1rem 1.1rem;
        box-shadow: 0 4px 14px rgba(30, 60, 100, 0.04);
    }
    .metric-label {
        color: #61728a;
        font-size: .88rem;
        margin-bottom: .3rem;
    }
    .metric-value {
        color: #173c70;
        font-size: 1.8rem;
        font-weight: 750;
    }
    div[data-testid="stForm"] {
        background: white;
        border: 1px solid #e4ebf5;
        padding: 1.1rem;
        border-radius: 16px;
    }
    .medicine-card {
        background: white;
        border: 1px solid #e4ebf5;
        border-radius: 15px;
        padding: 1rem 1.1rem;
        margin-bottom: .8rem;
    }
    .medicine-name {
        color: #173c70;
        font-weight: 700;
        font-size: 1.08rem;
    }
    .muted {
        color: #64748b;
        font-size: .9rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# -------------------- HEADER --------------------
st.markdown(
    """
    <div class="hero">
        <h1>💊 MediMate</h1>
        <p>Your medicines, organised in one simple place.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

today = date.today()
all_medicines = get_medicines()
today_medicines = [
    med for med in all_medicines
    if med["start_date"] == today.isoformat()
]

m1, m2, m3 = st.columns(3)
with m1:
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">Total medicines</div>'
        f'<div class="metric-value">{len(all_medicines)}</div></div>',
        unsafe_allow_html=True,
    )
with m2:
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">Starting today</div>'
        f'<div class="metric-value">{len(today_medicines)}</div></div>',
        unsafe_allow_html=True,
    )
with m3:
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">Today\'s date</div>'
        f'<div class="metric-value" style="font-size:1.35rem">{today.strftime("%d %b %Y")}</div></div>',
        unsafe_allow_html=True,
    )

st.write("")


# -------------------- SIDEBAR --------------------
with st.sidebar:
    st.markdown("## 💊 MediMate")
    st.caption("Medicine schedule manager")
    menu_options = ["Dashboard", "Add medicine", "My medicines"]
    selected_page = st.session_state.get("selected_page", "Dashboard")
    selected_index = menu_options.index(selected_page) if selected_page in menu_options else 0
    page = st.radio(
        "MENU",
        menu_options,
        index=selected_index,
        label_visibility="visible",
    )
    st.session_state["selected_page"] = page
    st.divider()
    st.caption("Reminder times are saved as a schedule. Device notifications are not enabled in this version.")


# -------------------- DASHBOARD --------------------
if page == "Dashboard":
    left, right = st.columns([1.3, 1], gap="large")

    with left:
        st.subheader("📅 Today's schedule")
        if not today_medicines:
            st.info("No medicines have a start date of today.")
        else:
            for med in sorted(today_medicines, key=lambda x: x["reminder_time"]):
                st.markdown(
                    f"""
                    <div class="medicine-card">
                        <div class="medicine-name">💊 {med["name"]}</div>
                        <div class="muted">⏰ {med["reminder_time"]} &nbsp; · &nbsp; {med["dosage"]}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    with right:
        st.subheader("⚡ Quick actions")
        if st.button("➕ Add a medicine", use_container_width=True, type="primary"):
            st.session_state["selected_page"] = "Add medicine"
            st.rerun()
        if st.button("📋 View all medicines", use_container_width=True):
            st.session_state["selected_page"] = "My medicines"
            st.rerun()
        st.write("")
        st.subheader("💡 Helpful tip")
        st.write(
            "Enter medicine details exactly as instructed by your healthcare professional. "
            "Check the schedule regularly to keep it up to date."
        )

    # Quick-action navigation is handled by the sidebar selection on rerun.


# -------------------- ADD MEDICINE --------------------
elif page == "Add medicine":
    st.subheader("➕ Add a medicine")
    st.write("Fill in the details below to add it to your schedule.")

    with st.form("add_medicine_form", clear_on_submit=True):
        name = st.text_input("Medicine name *", placeholder="e.g., Medicine name")
        dosage = st.text_input(
            "Dosage instructions *",
            placeholder="e.g., As prescribed by your doctor",
        )
        c1, c2 = st.columns(2)
        with c1:
            start_date = st.date_input("Start date", value=today, min_value=date(1900, 1, 1))
        with c2:
            reminder_time = st.time_input("Reminder time", value=time(8, 0))
        notes = st.text_area("Additional notes (optional)", placeholder="Any notes to help you remember")
        submitted = st.form_submit_button("💾 Save medicine", use_container_width=True, type="primary")

    if submitted:
        if not name.strip() or not dosage.strip():
            st.error("Please enter both the medicine name and dosage instructions.")
        else:
            try:
                add_medicine(name, dosage, start_date, reminder_time, notes)
                st.success(f"'{name.strip()}' has been added to your medicine schedule.")
                st.rerun()
            except sqlite3.Error:
                st.error("The medicine could not be saved. Please try again.")


# -------------------- MY MEDICINES --------------------
elif page == "My medicines":
    st.subheader("📋 My medicines")
    search_term = st.text_input(
        "🔎 Search medicines",
        placeholder="Search by name, dosage, or notes...",
    )
    medicines = get_medicines(search_term)

    if not medicines:
        if search_term:
            st.warning("No medicines match your search.")
        else:
            st.info("Your medicine list is empty. Open **Add medicine** to create your first entry.")
    else:
        st.caption(f"{len(medicines)} medicine(s) found")
        for med in medicines:
            with st.container(border=True):
                details, action = st.columns([5, 1])
                with details:
                    st.markdown(f"### 💊 {med['name']}")
                    st.write(f"**Dosage instructions:** {med['dosage']}")
                    st.write(f"**Start date:** {med['start_date']}")
                    st.write(f"**Reminder time:** {med['reminder_time']}")
                    if med["notes"]:
                        st.write(f"**Notes:** {med['notes']}")
                with action:
                    st.write("")
                    confirm_key = f"confirm_delete_{med['id']}"
                    if st.button("🗑️ Delete", key=f"delete_{med['id']}", use_container_width=True):
                        st.session_state[confirm_key] = True
                    if st.session_state.get(confirm_key):
                        st.warning("Delete this entry?")
                        yes_col, no_col = st.columns(2)
                        with yes_col:
                            if st.button("Yes", key=f"yes_{med['id']}"):
                                delete_medicine(med["id"])
                                st.session_state.pop(confirm_key, None)
                                st.success("Medicine deleted.")
                                st.rerun()
                        with no_col:
                            if st.button("Cancel", key=f"cancel_{med['id']}"):
                                st.session_state.pop(confirm_key, None)
                                st.rerun()

st.divider()
st.caption("MediMate helps organise a medicine schedule. It does not replace professional medical advice.")
