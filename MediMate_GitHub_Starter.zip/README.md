# MediMate — Smart Medicine Reminder

MediMate is a Streamlit app for organising medicine names, dosage instructions, start dates, reminder times, and notes.

## Features
- Add and view medicine schedule entries
- Search by medicine name, dosage, or notes
- Delete entries with confirmation
- Dashboard summary
- SQLite storage

## Run locally
1. Install Python 3.10 or newer.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run:
   ```bash
   streamlit run app.py
   ```

## Deploy on Streamlit Community Cloud
1. Push `app.py`, `requirements.txt`, and `README.md` to a GitHub repository.
2. Open https://share.streamlit.io
3. Connect GitHub and choose the repository.
4. Set the main file path to `app.py` and deploy.

## Important deployment note
The SQLite database is stored beside the app file. On hosted deployments, local files may not be persistent across rebuilds/restarts. For durable multi-user storage, connect a hosted database. Reminder times are saved as schedule information; this version does not send device notifications.
